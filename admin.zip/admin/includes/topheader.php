<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav right">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="fas fa-user-circle"></i>  <span class="text">Bienvenido Administrador</span><b class="caret"></b></a>
      <ul class="dropdown-menu">
        <!-- la clase fa-user es la del icono de un usuario de la libreria font awesome-->
        <li><a href="#"><i class="fas fa-user"></i> Mi perfil</a></li>
        <li class="divider"></li>
        <!-- la clase fa-check es la del icono de un check de la libreria font awesome-->
        <li><a href="#"><i class="fas fa-check"></i> Mis tareas</a></li>
        <li class="divider"></li>
        <!-- la clase fa-power-off es la del icono de cerrar sesion de la libreria font awesome-->
        <li><a href="../logout.php"><i class="fas fa-power-off"></i> Cerrar sesion</a></li>
      </ul>
    </li>
    
    <li class=""><a title="" href="../logout.php"><i class="fas fa-power-off">  </i> <span class="text">Cerrar sesion</span></a></li>
  </ul>
</div>