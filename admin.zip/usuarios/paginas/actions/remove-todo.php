<?php
// <!-- Visit codeastro.com for more projects -->
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
header('location:../index.php');	
}

if(isset($_GET['id'])){
$id=$_GET['id'];

include 'dbconexion.php';


$qry="delete from todo where id=$id";
$result=mysqli_query($con,$qry);

if($result){
    echo"DELETED";
    header('Location:../index.php');
}else{
    echo"ERROR!!";
}
}
?>